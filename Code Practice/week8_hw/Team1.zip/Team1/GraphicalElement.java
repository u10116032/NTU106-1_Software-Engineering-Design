public class GraphicalElement extends Component{
	
	public GraphicalElement(int componentId, int naturalSize, int stretchability, int shrinkability, String content)
	{
		super(componentId, naturalSize, stretchability, shrinkability, content);
	}
	
}
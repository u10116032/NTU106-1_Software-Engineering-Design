public class Text extends Component{
	
	public Text(int componentId, int naturalSize, int stretchability, int shrinkability, String content)
	{
		super(componentId, naturalSize, stretchability, shrinkability, content);
	}

}
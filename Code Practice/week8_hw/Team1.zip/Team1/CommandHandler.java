import java.util.*;

public interface CommandHandler{

	void execute(List<String> tokens);

}
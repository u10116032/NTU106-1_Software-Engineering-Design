import java.util.*;

public interface Compositor{

	void compose(Map<Integer, Component> componentMap);

}